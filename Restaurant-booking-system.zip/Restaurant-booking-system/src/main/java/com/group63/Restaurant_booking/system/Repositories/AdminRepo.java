package com.group63.Restaurant_booking.system.Repositories;
import org.springframework.data.jpa.repository.JpaRepository;
import com.group63.Restaurant_booking.system.Entity.Admin;
public interface AdminRepo extends JpaRepository<Admin, Integer>{



}
