package com.group63.Restaurant_booking.system.Controller;
import com.group63.Restaurant_booking.system.Entity.Restaurants;
import com.group63.Restaurant_booking.system.Repositories.RestaurantRepo;
import com.group63.Restaurant_booking.system.Services.RestaurantService ;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;



@RestController
@RequestMapping("/restaurant")

public class RestaurantController {

    @Autowired
    private RestaurantService restaurantService ;

   @GetMapping("/user/{userID}")
    public ResponseEntity<List<Restaurants>> getRestaurantByID(@PathVariable Integer restaurantID){

       List<Restaurants> restaurants = restaurantService.getRestaurantByID(restaurantID);
       return ResponseEntity.ok(restaurants);

   }


   @PostMapping("save")

    public ResponseEntity<Restaurants> saveRestaurant(@RequestBody Restaurants restaurant) {


     return   ResponseEntity.ok(restaurantService.saveRestaurants(restaurant)) ;

   }


}
