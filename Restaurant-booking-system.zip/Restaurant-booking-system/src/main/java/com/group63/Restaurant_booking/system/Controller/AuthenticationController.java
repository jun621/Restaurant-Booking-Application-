package com.group63.Restaurant_booking.system.Controller;

public class AuthenticationController {
}
