package com.group63.Restaurant_booking.system.Services;

public interface RestaurantServiceImpl {
}
