package com.group63.Restaurant_booking.system.Services;

public class NotificationService implements NotificationServiceImpl{
}
