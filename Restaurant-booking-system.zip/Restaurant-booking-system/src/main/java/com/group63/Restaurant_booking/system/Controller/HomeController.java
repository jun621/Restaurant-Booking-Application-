package com.group63.Restaurant_booking.system.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import javax.management.Notification;
import java.util.*;
import org.springframework.web.servlet.ModelAndView;

@RequestMapping("/")
@RestController
public class HomeController {


        @GetMapping("/home")
        public String showHomePage() {
            return "home"; // home.html
        }

    @GetMapping("/dashboard")
    public ModelAndView showDashboard() {
        ModelAndView modelAndView = new ModelAndView("dashboard");
        return modelAndView;
    }

        @GetMapping("/error")
        public String showErrorPage() {
            return "error"; // error.html
        }


}
