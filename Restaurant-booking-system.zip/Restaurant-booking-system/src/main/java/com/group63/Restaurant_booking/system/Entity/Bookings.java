package com.group63.Restaurant_booking.system.Entity;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;


@Entity
@Table (name = "Bookings")
public class Bookings {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Integer BookingID;

    private Integer UserID;

    private Integer RestaurantID;

    private LocalDate Date ;

    private LocalTime Time;

    private Integer   NumberOfPeople;

    private String Status;

    private Integer AdminID;

     public Bookings() { }

    public Bookings (Integer UserID, Integer RestaurantID, LocalDate Date, LocalTime Time, Integer NumberOfPeople, String Status, Integer AdminID ) {
      this.UserID = UserID;
      this.RestaurantID = RestaurantID;
      this.Date= Date;
      this.Time = Time;
      this.NumberOfPeople= NumberOfPeople;
      this.Status = Status;
      this.AdminID= AdminID;
    }

    public Integer getBookingID() {
        return BookingID;
    }

    public void setBookingID(Integer bookingID) {
        BookingID = bookingID;
    }

    public Integer getUserID() {
        return UserID;
    }

    public void setUserID(Integer userID) {
        UserID = userID;
    }

    public Integer getRestaurantID() {
        return RestaurantID;
    }

    public void setRestaurantID(Integer restaurantID) {
        RestaurantID = restaurantID;
    }

    public LocalDate getDate() {
        return Date;
    }

    public void setDate(LocalDate date) {
        Date = date;
    }

    public LocalTime getTime() {
        return Time;
    }

    public void setTime(LocalTime time) {
        Time = time;
    }

    public Integer getNumberOfPeople() {
        return NumberOfPeople;
    }

    public void setNumberOfPeople(Integer numberOfPeople) {
        NumberOfPeople = numberOfPeople;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public Integer getAdminID() {
        return AdminID;
    }

    public void setAdminID(Integer adminID) {
        AdminID = adminID;
    }

    @Override
    public String toString() {
        return "Bookings{" +
                "BookingID=" + BookingID +
                ", UserID=" + UserID +
                ", RestaurantID=" + RestaurantID +
                ", Date=" + Date +
                ", Time=" + Time +
                ", NumberOfPeople=" + NumberOfPeople +
                ", Status='" + Status + '\'' +
                ", AdminID=" + AdminID +
                '}';
    }


}
