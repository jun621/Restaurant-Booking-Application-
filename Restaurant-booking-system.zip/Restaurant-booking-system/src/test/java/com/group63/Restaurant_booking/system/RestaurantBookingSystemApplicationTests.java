package com.group63.Restaurant_booking.system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantBookingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
