package com.group63.Restaurant_booking.system.Entity;
import jakarta.persistence.*;


@Entity
@Table(name="Restaurants")
public class Restaurants {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)

    private Integer restaurantID;
    private String Name ;
    private String Address;

    private Integer NumberOfTables;
    private String PhoneNumber;

   public Restaurants () {}

    public Restaurants (String Name, String Address, Integer NumberOfTables, String PhoneNumber) {

       this.Name = Name ;
       this.Address= Address;
       this.NumberOfTables= NumberOfTables;
       this.PhoneNumber= PhoneNumber;
    }


    public Integer getRestaurantID() {
        return restaurantID;
    }

    public void setRestaurantID(Integer restaurantID) {
        this.restaurantID = restaurantID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public Integer getNumberOfTables() {
        return NumberOfTables;
    }

    public void setNumberOfTables(Integer numberOfTables) {
        NumberOfTables = numberOfTables;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    @Override
    public String toString() {
        return "Restaurants{" +
                "RestaurantID=" + restaurantID +
                ", Name='" + Name + '\'' +
                ", Address='" + Address + '\'' +
                ", NumberOfTables=" + NumberOfTables +
                ", PhoneNumber='" + PhoneNumber + '\'' +
                '}';
    }





}
