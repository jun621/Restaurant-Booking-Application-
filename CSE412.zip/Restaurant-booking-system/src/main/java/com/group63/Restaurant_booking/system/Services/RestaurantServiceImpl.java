package com.group63.Restaurant_booking.system.Services;
import com.group63.Restaurant_booking.system.Entity.Restaurants;
import java.util.Optional;
import java.util.List;
public interface RestaurantServiceImpl {

List <Restaurants> getRestaurantByID (Integer RestaurantID) ;
Restaurants saveRestaurants(Restaurants restaurant) ;

List<Restaurants> getAllRestaurants();

void deleteRestaurantById(Integer restaurantID);

}
