package com.group63.Restaurant_booking.system.Services;

import com.group63.Restaurant_booking.system.Entity.Restaurants;
import com.group63.Restaurant_booking.system.Repositories.RestaurantRepo;
import com.group63.Restaurant_booking.system.Services.RestaurantServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;
import java.util.List;

@Service
public class RestaurantService implements RestaurantServiceImpl{

    @Autowired
    private RestaurantRepo restaurantRepo;

    @Override
    public List<Restaurants> getRestaurantByID(Integer RestaurantID) {
        return restaurantRepo.findByRestaurantID(RestaurantID);
    }

    @Override
    public Restaurants saveRestaurants(Restaurants restaurant) {
        return restaurantRepo.save(restaurant);
    }

    @Override
    public List<Restaurants> getAllRestaurants() {
        return restaurantRepo.findAll();
    }

    @Override
    public void deleteRestaurantById(Integer restaurantID) {

        // Check if the restaurant exists before attempting deletion
        if (restaurantRepo.existsById(restaurantID)) {
            restaurantRepo.deleteById(restaurantID);
        } else {
            throw new IllegalArgumentException("Restaurant with ID " + restaurantID + " does not exist.");
        }
    }
}
